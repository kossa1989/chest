import conf
import Hashconf



#Created by Kosa



